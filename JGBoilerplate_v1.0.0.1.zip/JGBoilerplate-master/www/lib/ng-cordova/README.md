angular-cordova
===============

Let´s make some angular-cordova apps!
